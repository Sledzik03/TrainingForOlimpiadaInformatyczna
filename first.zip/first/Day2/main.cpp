#include <bits/stdc++.h>

using namespace std;

string S;
int K;
int result;


int main()
{
    getline(cin,S);
    cin >> K;

    return 0;
}
