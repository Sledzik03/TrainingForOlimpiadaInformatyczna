#include <bits/stdc++.h>
using namespace std;
int N,K;
int A[100000];
int licz(int);
int licz(int d)
{

}
int main()
{
    cin >> N >> K;
    for (int i=0;i<N;i++)
    {
        cin >> A[i];
    }

    return 0;

}
