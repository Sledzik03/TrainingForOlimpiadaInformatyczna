#include <iostream>
#include <stack>
#include <vector>
//todo: wejscie vector string, konczy \n
//todo: 3 zalozenia i wykorzystanie stosu
//todo: wypisanie wyniku (int), int only, 3 dzia�ania: + - *
using namespace std;

stack <string> liczby;


int main()
{







    return(0);
}
