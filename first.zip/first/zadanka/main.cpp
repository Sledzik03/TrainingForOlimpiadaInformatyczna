#include <bits/stdc++.h>

using namespace std;
int n;
int licznik=0;
int main()
{
        cin >> n;
        for (int i=1;i<=n;i++)
        {
            for (int j=1;j<=n;j++)
            {
                cout << "0";
             licznik++;
              /*if (licznik = (n/2)+1)
              {

              }*/
            }
            cout << endl;
        }
    return 0;
}
