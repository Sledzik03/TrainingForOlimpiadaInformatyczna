a=int(input())

