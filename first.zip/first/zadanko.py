x=input()
while x!=0:
    if x%3==0:
        licznik = licznik + 1


print (licznik)
exit
