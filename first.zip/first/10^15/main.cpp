#include <bits/stdc++.h>

using namespace std;

int main()
{
    cout << fixed;
    cout << setprecision(0);
    cout << pow(10,15);
    return 0;
}
