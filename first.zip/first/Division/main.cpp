#include <bits/stdc++.h>

using namespace std;
string A;
int main()
{
    cin >> A;
    int n = A.length();


    return 0;
}
