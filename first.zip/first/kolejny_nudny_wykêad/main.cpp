#include <iostream>

using namespace std;

int main()
{
    int x;
    cin >> x;

    return 0;
}
