#include <iostream>

using namespace std;

int main()
{
int k,w,m;  //k-kozik,w-wymagany wzrost,m-wartosc powiekszenia guza



    return 0;
}
