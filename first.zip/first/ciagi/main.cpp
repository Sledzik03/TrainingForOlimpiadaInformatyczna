#include <iostream>

using namespace std;

int main()
{
    int z,x[z];
    cin >> z;
    for (int i = 0; i<z;i++)
    {
        cin >> x[i];

    if ()
    {
        cout << "TAK"<<endl;
    }else cout<<"NIE"<<endl;}

    return 0;

}
