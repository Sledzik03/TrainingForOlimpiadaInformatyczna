#include <iostream>

using namespace std;

int main()
{
    int a[11];

    cin >> a;

    return 0;
}
